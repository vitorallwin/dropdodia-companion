$ErrorActionPreference = 'Stop'

$installRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$versionPath = Join-Path $installRoot 'version.json'
$logRoot = Join-Path $installRoot 'logs'
$logPath = Join-Path $logRoot 'atualizacoes.log'
$manifestUrl = 'https://raw.githubusercontent.com/vitorallwin/dropdodia-companion/main/downloads/latest.json'

function Write-UpdateLog([string]$message) {
  New-Item -ItemType Directory -Force -Path $logRoot | Out-Null
  $timestamp = Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'
  Add-Content -LiteralPath $logPath -Value "[$timestamp] $message" -Encoding UTF8
}

try {
  if (-not (Test-Path -LiteralPath $versionPath -PathType Leaf)) {
    Write-UpdateLog 'Atualizacao automatica ignorada: versao local nao encontrada.'
    return
  }

  $localInfo = Get-Content -LiteralPath $versionPath -Raw | ConvertFrom-Json
  $localVersion = [version]$localInfo.version
  $manifest = Invoke-RestMethod -Uri $manifestUrl -TimeoutSec 8 -Headers @{ 'Cache-Control' = 'no-cache' }
  $remoteVersion = [version]$manifest.version

  if ($remoteVersion -le $localVersion) { return }
  if ($manifest.download_url -notmatch '^https://raw\.githubusercontent\.com/vitorallwin/dropdodia-companion/') {
    throw 'A origem do pacote de atualizacao nao e permitida.'
  }
  if ([string]$manifest.sha256 -notmatch '^[A-Fa-f0-9]{64}$') {
    throw 'O manifesto de atualizacao possui hash invalido.'
  }

  $updateRoot = Join-Path $env:TEMP ("DropDoDia-update-" + [guid]::NewGuid().ToString('N'))
  $zipPath = Join-Path $updateRoot 'atualizacao.zip'
  $extractRoot = Join-Path $updateRoot 'extraido'
  New-Item -ItemType Directory -Force -Path $extractRoot | Out-Null

  Write-UpdateLog "Baixando atualizacao $localVersion -> $remoteVersion"
  Invoke-WebRequest -Uri $manifest.download_url -OutFile $zipPath -TimeoutSec 120 | Out-Null
  $zipStream = [System.IO.File]::OpenRead($zipPath)
  try {
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    $downloadHash = ([System.BitConverter]::ToString($sha256.ComputeHash($zipStream))).Replace('-', '')
  } finally {
    if ($sha256) { $sha256.Dispose() }
    $zipStream.Dispose()
  }
  if (-not $downloadHash.Equals([string]$manifest.sha256, [System.StringComparison]::OrdinalIgnoreCase)) {
    throw 'A verificacao de integridade da atualizacao falhou.'
  }

  Expand-Archive -LiteralPath $zipPath -DestinationPath $extractRoot -Force
  $packageRoot = Join-Path $extractRoot 'DropDoDia-Curadoria-Windows'
  $installerPath = Join-Path $packageRoot 'instalar.ps1'
  $packageVersionPath = Join-Path $packageRoot 'version.json'
  if (-not (Test-Path -LiteralPath $installerPath -PathType Leaf) -or
      -not (Test-Path -LiteralPath $packageVersionPath -PathType Leaf)) {
    throw 'O pacote de atualizacao esta incompleto.'
  }
  $packageInfo = Get-Content -LiteralPath $packageVersionPath -Raw | ConvertFrom-Json
  if ([version]$packageInfo.version -ne $remoteVersion) {
    throw 'A versao do pacote nao corresponde ao manifesto.'
  }

  Write-UpdateLog "Pacote $remoteVersion validado; iniciando instalacao."
  Start-Process -FilePath 'powershell.exe' `
    -ArgumentList @('-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', $installerPath) `
    -WorkingDirectory $packageRoot `
    -WindowStyle Hidden
  Write-Output 'UPDATE_STARTED'
  return
} catch {
  Write-UpdateLog "Atualizacao ignorada; a versao instalada sera usada: $($_.Exception.Message)"
  return
}
