'use strict';

const http = require('node:http');
const { createHash, randomUUID } = require('node:crypto');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const HOST = '127.0.0.1';
const PORT = Number(process.env.ML_COMPANION_PORT || 8791);
const MODE = process.env.ML_COMPANION_MODE === 'real' ? 'real' : 'mock';
const COMPANION_VERSION = (() => {
  for (const versionPath of [
    path.join(__dirname, '..', 'version.json'),
    path.join(__dirname, 'distribution', 'version.json')
  ]) {
    try {
      return String(JSON.parse(fs.readFileSync(versionPath, 'utf8')).version || 'desconhecida');
    } catch {}
  }
  return 'desenvolvimento';
})();
const allowedHosts = new Set([`127.0.0.1:${PORT}`, `localhost:${PORT}`]);
const allowedOrigins = new Set([
  'http://localhost:8790',
  'http://127.0.0.1:8790',
  'https://dropdodia.com.br',
  'https://www.dropdodia.com.br',
  ...(process.env.ML_ADMIN_ORIGIN || '').split(',').map(item => item.trim()).filter(Boolean)
]);
const CLIENT_ID = '3854534117905624';
const REDIRECT_URI = 'https://dropdodia.com.br';
const oauth = {
  pendingState:null,
  pendingUntil:0,
  clientSecret:null,
  accessToken:null,
  refreshToken:null,
  expiresAt:0,
  userId:null
};
const EDGE_PATH = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const EDGE_DEBUG_PORT = 9223;
const affiliateSession = {browserProcess:null, targetId:null, targetUrl:null, csrfToken:null, tag:null, validatedAt:0};
const CATEGORIAS = [
  {id:'tecnologia', name:'Tecnologia', seeds:[
    {id:'smartphones', query:'smartphone', match:/smartphone|celular/i},
    {id:'notebooks', query:'notebook', match:/notebook|laptop/i},
    {id:'tablets', query:'tablet', match:/tablet|ipad/i},
    {id:'relogios', query:'smartwatch', match:/smartwatch|relogio inteligente/i},
    {id:'monitores', query:'monitor computador', match:/monitor/i},
    {id:'audio', query:'fone bluetooth', match:/fone|headphone|earbuds/i},
    {id:'caixas-som', query:'caixa de som bluetooth', match:/caixa de som|speaker/i},
    {id:'armazenamento', query:'ssd', match:/ssd|nvme/i},
    {id:'roteadores', query:'roteador wifi', match:/roteador|mesh/i},
    {id:'impressoras', query:'impressora', match:/impressora/i},
    {id:'teclados', query:'teclado computador', match:/teclado/i},
    {id:'mouses', query:'mouse computador', match:/mouse/i},
    {id:'carregadores', query:'carregador usb c', match:/carregador/i},
    {id:'hubs', query:'hub usb c', match:/hub usb|dock station/i},
    {id:'cameras', query:'camera de seguranca wifi', match:/camera/i}
  ]},
  {id:'casa', name:'Casa e Cozinha', seeds:[
    {id:'airfryer', query:'air fryer', match:/air\s?fryer|fritadeira/i},
    {id:'aspiradores', query:'aspirador de po', match:/aspirador/i},
    {id:'cafeteiras', query:'cafeteira', match:/cafeteira/i},
    {id:'panelas', query:'panela eletrica', match:/panela/i},
    {id:'liquidificadores', query:'liquidificador', match:/liquidificador/i},
    {id:'microondas', query:'microondas', match:/micro-?ondas/i},
    {id:'ventiladores', query:'ventilador', match:/ventilador/i},
    {id:'ferros', query:'ferro de passar', match:/ferro.*passar/i},
    {id:'roupa-cama', query:'jogo de cama', match:/jogo de cama|lencol|edredom/i},
    {id:'organizadores', query:'organizador casa', match:/organizador/i},
    {id:'iluminacao', query:'luminaria led', match:/luminaria|abajur/i},
    {id:'copos', query:'jogo de copos', match:/copo|taca/i},
    {id:'facas', query:'jogo de facas', match:/faca/i},
    {id:'mop', query:'mop limpeza', match:/\bmop\b/i},
    {id:'jardim', query:'mangueira jardim', match:/mangueira/i}
  ]},
  {id:'games', name:'Games', seeds:[
    {id:'consoles', query:'console videogame', match:/playstation|xbox|nintendo|console/i},
    {id:'controles', query:'controle videogame', match:/controle|joystick|gamepad/i},
    {id:'headsets', query:'headset gamer', match:/headset/i},
    {id:'cadeiras', query:'cadeira gamer', match:/cadeira/i},
    {id:'jogos', query:'jogo playstation', match:/jogo|game|playstation/i},
    {id:'volantes', query:'volante gamer', match:/volante/i},
    {id:'mousepads', query:'mousepad gamer', match:/mouse\s?pad/i},
    {id:'microfones', query:'microfone gamer', match:/microfone/i},
    {id:'mesas', query:'mesa gamer', match:/mesa gamer/i},
    {id:'placas-video', query:'placa de video gamer', match:/placa de video|geforce|radeon/i},
    {id:'memorias', query:'memoria ram gamer', match:/memoria ram|ddr[45]/i},
    {id:'fontes', query:'fonte pc gamer', match:/fonte/i}
  ]},
  {id:'ferramentas', name:'Ferramentas', seeds:[
    {id:'parafusadeiras', query:'parafusadeira', match:/parafusadeira/i},
    {id:'furadeiras', query:'furadeira', match:/furadeira/i},
    {id:'serras', query:'serra eletrica', match:/serra/i},
    {id:'kits', query:'kit ferramentas', match:/ferramenta|jogo de chave/i},
    {id:'chaves', query:'chave de fenda', match:/chave.*fenda|chave.*phillips/i},
    {id:'esmerilhadeiras', query:'esmerilhadeira', match:/esmerilhadeira/i},
    {id:'multimetros', query:'multimetro', match:/multimetro/i},
    {id:'trenas', query:'trena laser', match:/trena/i},
    {id:'solda', query:'maquina de solda', match:/solda/i},
    {id:'compressores', query:'compressor de ar', match:/compressor/i},
    {id:'lavadoras', query:'lavadora de alta pressao', match:/lavadora.*pressao/i},
    {id:'caixas', query:'caixa de ferramentas', match:/caixa.*ferramenta/i},
    {id:'epis', query:'oculos de protecao trabalho', match:/oculos.*protecao/i},
    {id:'jardinagem', query:'aparador de grama', match:/aparador.*grama|rocadeira/i}
  ]},
  {id:'beleza', name:'Beleza', seeds:[
    {id:'secadores', query:'secador de cabelo', match:/secador/i},
    {id:'barbeadores', query:'barbeador eletrico', match:/barbeador|aparador/i},
    {id:'chapinhas', query:'chapinha cabelo', match:/chapinha|prancha/i},
    {id:'perfumes', query:'perfume', match:/perfume|eau de/i},
    {id:'escovas', query:'escova secadora', match:/escova/i},
    {id:'protetor-solar', query:'protetor solar', match:/protetor solar/i},
    {id:'hidratantes', query:'hidratante facial', match:/hidratante/i},
    {id:'seruns', query:'serum facial', match:/serum|sérum/i},
    {id:'maquiagem', query:'kit maquiagem', match:/maquiagem/i},
    {id:'bases', query:'base maquiagem', match:/base.*facial|base.*maquiagem/i},
    {id:'batons', query:'batom', match:/batom/i},
    {id:'manicure', query:'kit manicure', match:/manicure|unha/i},
    {id:'massageadores', query:'massageador eletrico', match:/massageador/i},
    {id:'cuidados-bucais', query:'escova de dente eletrica', match:/escova.*dente/i},
    {id:'shampoo', query:'kit shampoo', match:/shampoo/i}
  ]}
];
const cacheCategorias = new Map();
const rotacaoCategorias = new Map();
const ultimaDescobertaPorCategoria = new Map();

function responder(res, status, payload){
  res.writeHead(status, {
    'Content-Type':'application/json; charset=utf-8',
    'Access-Control-Allow-Origin':res.corsOrigin || 'null',
    'Access-Control-Allow-Headers':'Content-Type',
    'Access-Control-Allow-Methods':'GET,POST,OPTIONS',
    'Access-Control-Allow-Private-Network':'true',
    'Access-Control-Max-Age':'600',
    'Vary':'Origin, Access-Control-Request-Private-Network',
    'X-Content-Type-Options':'nosniff',
    'Referrer-Policy':'no-referrer',
    'Cache-Control':'no-store'
  });
  res.end(JSON.stringify(payload));
}

function lerJson(req){
  return new Promise((resolve, reject) => {
    let texto = '';
    req.on('data', bloco => {
      texto += bloco;
      if (texto.length > 256 * 1024) req.destroy(new Error('payload muito grande'));
    });
    req.on('end', () => {
      try { resolve(texto ? JSON.parse(texto) : {}); }
      catch { reject(new Error('JSON inválido')); }
    });
    req.on('error', reject);
  });
}

function produtoDePrevia(candidato){
  if (!candidato?.itemId || !candidato?.title || !Number.isFinite(Number(candidato?.price))){
    const erro = new Error('candidato incompleto');
    erro.code = 'VALIDATION_ERROR';
    throw erro;
  }
  const categoriasSite = {
    tecnologia:'eletronicos',
    casa:'casa',
    games:'games',
    ferramentas:'ferramentas',
    beleza:'beleza'
  };
  const id = idPublicacaoMercadoLivre(candidato.productIdentity || candidato.catalogProductId || candidato.itemId);
  return {
    id,
    titulo: candidato.publicTitle || candidato.title,
    titulo_original: candidato.sourceTitle || candidato.title,
    nome_canonico: candidato.canonicalName || candidato.title,
    identidade_produto: candidato.productIdentity || null,
    marca: candidato.brand || null,
    modelo: candidato.model || null,
    part_number: candidato.partNumber || null,
    atributos_origem: candidato.sourceAttributes || {},
    descricao: 'Oferta selecionada pela curadoria Mercado Livre.',
    link: candidato.affiliateUrl || `https://meli.la/preview-${candidato.itemId.toLowerCase()}`,
    imagem_url: candidato.image || null,
    preco: Number(candidato.price),
    preco_de: Number(candidato.originalPrice) > Number(candidato.price) ? Number(candidato.originalPrice) : null,
    avaliacao: null,
    loja_id: 'mercadolivre',
    categoria_id: categoriasSite[candidato.editorialCategory] || 'outros',
    destaque: false,
    ativo: true,
    mercadolivre_item_id: String(candidato.itemId),
    mercadolivre_catalog_product_id: String(candidato.catalogProductId),
    preco_verificado_em: new Date().toISOString()
  };
}

async function verificarPrecosMercadoLivre(itens){
  if (!Array.isArray(itens) || !itens.length) return [];
  if (itens.length > 100) throw criarErro('TOO_MANY_ITEMS', 'verifique no máximo 100 produtos por vez');

  return Promise.all(itens.map(async item => {
    const itemId = String(item?.itemId || '');
    const catalogProductId = String(item?.catalogProductId || '');
    if (!/^MLB\d+$/.test(itemId) || !/^MLB\d+$/.test(catalogProductId)){
      return {id:item?.id || null, itemId, status:'invalid', message:'identificadores do anúncio inválidos'};
    }
    try {
      const resposta = await mercadoGet(`/products/${encodeURIComponent(catalogProductId)}/items`);
      const oferta = escolherOferta(listaDe(resposta));
      if (!oferta || oferta.price == null){
        return {id:item?.id || null, itemId, status:'unavailable', checkedAt:new Date().toISOString()};
      }
      return {
        id:item?.id || null,
        itemId:String(oferta.item_id),
        previousItemId:itemId,
        offerChanged:String(oferta.item_id) !== itemId,
        status:'available',
        price:Number(oferta.price),
        originalPrice:oferta.original_price == null ? null : Number(oferta.original_price),
        sellerId:oferta.seller_id || oferta.seller?.id || null,
        officialStoreId:oferta.official_store_id || null,
        checkedAt:new Date().toISOString()
      };
    } catch (erro) {
      if (erro.code === 'SESSION_REQUIRED') throw erro;
      return {id:item?.id || null, itemId, status:'error', message:erro.message};
    }
  }));
}

function idPublicacaoMercadoLivre(itemId){
  const hex = createHash('sha256')
    .update(`mercadolivre:${String(itemId || '').toUpperCase()}`)
    .digest('hex')
    .slice(0, 32)
    .split('');
  hex[12] = '5';
  hex[16] = ((parseInt(hex[16], 16) & 3) | 8).toString(16);
  const valor = hex.join('');
  return `${valor.slice(0,8)}-${valor.slice(8,12)}-${valor.slice(12,16)}-${valor.slice(16,20)}-${valor.slice(20)}`;
}

function urlPublicaItem(itemId){
  const numero = String(itemId || '').replace(/^MLB-?/, '');
  if (!/^\d+$/.test(numero)) throw criarErro('INVALID_ITEM_ID', 'item do Mercado Livre inválido');
  return `https://produto.mercadolivre.com.br/MLB-${numero}`;
}

async function alvosAfiliados(){
  const resposta = await fetch(`http://127.0.0.1:${EDGE_DEBUG_PORT}/json/list`, {signal:AbortSignal.timeout(2000)});
  const alvos = await resposta.json();
  return alvos
    .filter(alvo => alvo.type === 'page' && /mercadolivre\.com\.br/.test(alvo.url || ''))
    .sort((a, b) => {
      const pontuar = alvo => {
        let pontos = 0;
        if (alvo.id === affiliateSession.targetId) pontos += 1000;
        if (alvo.url === affiliateSession.targetUrl) pontos += 500;
        if (/afiliad|affiliate|link.builder|gerador.de.links/i.test(`${alvo.url} ${alvo.title || ''}`)) pontos += 100;
        if (/\/affiliate-program\/?$/.test(new URL(alvo.url).pathname)) pontos -= 50;
        return pontos;
      };
      return pontuar(b) - pontuar(a);
    })
    .slice(0, 3);
}

function avaliarNoAlvo(alvo, expression){
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(alvo.webSocketDebuggerUrl);
    const id = 1;
    let concluido = false;
    const concluir = (callback, valor) => {
      if (concluido) return;
      concluido = true;
      clearTimeout(timer);
      try { socket.close(); } catch {}
      callback(valor);
    };
    const timer = setTimeout(() => concluir(reject, criarErro('AFFILIATE_BROWSER_TIMEOUT', 'a janela do Mercado Livre não respondeu')), 5000);
    socket.addEventListener('open', () => socket.send(JSON.stringify({
      id,
      method:'Runtime.evaluate',
      params:{expression, awaitPromise:true, returnByValue:true}
    })));
    socket.addEventListener('message', evento => {
      const mensagem = JSON.parse(evento.data);
      if (mensagem.id !== id) return;
      if (mensagem.error || mensagem.result?.exceptionDetails){
        return concluir(reject, criarErro('AFFILIATE_BROWSER_EVAL_FAILED', 'não foi possível acessar a sessão afiliada'));
      }
      concluir(resolve, mensagem.result?.result?.value);
    });
    socket.addEventListener('error', () => concluir(reject, criarErro('AFFILIATE_BROWSER_REQUIRED', 'não foi possível conectar à janela afiliada')));
  });
}

async function avaliarNoEdge(expression, aceitar = () => true){
  let paginas = [];
  let ultimoErro = null;
  let primeiraResposta = null;
  for (let tentativa = 0; tentativa < 2; tentativa += 1){
    try { paginas = await alvosAfiliados(); }
    catch (erro) { ultimoErro = erro; paginas = []; }
    if (!paginas.length) break;
    for (const alvo of paginas){
      if (!alvo?.webSocketDebuggerUrl) continue;
      try {
        const valor = await avaliarNoAlvo(alvo, expression);
        primeiraResposta ||= {valor, alvo};
        if (aceitar(valor)) return {valor, alvo};
      } catch (erro) {
        ultimoErro = erro;
      }
    }
    await new Promise(resolve => setTimeout(resolve, 350));
  }
  if (primeiraResposta) return primeiraResposta;
  affiliateSession.targetId = null;
  affiliateSession.validatedAt = 0;
  if (ultimoErro) throw ultimoErro;
  throw criarErro('AFFILIATE_BROWSER_REQUIRED', 'a janela da Central de Afiliados não está aberta');
}

async function detectarSessaoAfiliada(){
  const avaliacao = await avaliarNoEdge(`(() => {
    const html = document.documentElement.innerHTML;
    const cookie = document.cookie;
    const meta = document.querySelector('meta[name="csrf-token"],meta[name="csrf_token"],meta[name="_csrf"]');
    const cookieCsrf = cookie.match(/(?:^|;\\s*)(?:_?csrf(?:Token)?|x-csrf-token)=([^;]+)/i);
    let storage = '';
    try { storage = JSON.stringify({...localStorage, ...sessionStorage}); } catch {}
    const csrfMatch = (meta?.content || '') || decodeURIComponent(cookieCsrf?.[1] || '') || (storage.match(/(?:csrf[^"']*["']?[:=]["'])([^"']+)/i)?.[1] || '');
    const tagMatch = (html + storage).match(/\\bva\\d{10,}\\b/i);
    return {url:location.href, title:document.title, csrfToken:csrfMatch || null, tag:tagMatch?.[0] || null};
  })()`, dados => !!(dados?.csrfToken && dados?.tag));
  const dados = avaliacao.valor;
  affiliateSession.targetId = avaliacao.alvo?.id || null;
  affiliateSession.targetUrl = dados?.url || null;
  affiliateSession.csrfToken = dados?.csrfToken || null;
  affiliateSession.tag = dados?.tag || null;
  affiliateSession.validatedAt = affiliateSession.csrfToken && affiliateSession.tag ? Date.now() : 0;
  return {configured:!!affiliateSession.validatedAt, url:affiliateSession.targetUrl, hasCsrf:!!affiliateSession.csrfToken, hasTag:!!affiliateSession.tag};
}

async function criarLinkAfiliado(publicUrl){
  const sessao = await detectarSessaoAfiliada();
  if (!sessao.configured) throw criarErro('AFFILIATE_SESSION_REQUIRED', 'abra o Gerador de Links na janela afiliada e aguarde a conexão');
  const expression = `(async () => {
    const resposta = await fetch('/affiliate-program/api/v2/affiliates/createLink', {
      method:'POST', credentials:'include',
      headers:{'Accept':'application/json','Content-Type':'application/json','x-csrf-token':${JSON.stringify(affiliateSession.csrfToken)}},
      body:JSON.stringify({urls:[${JSON.stringify(publicUrl)}],tag:${JSON.stringify(affiliateSession.tag)}})
    });
    let dados = {}; try { dados = await resposta.json(); } catch {}
    return {status:resposta.status,dados};
  })()`;
  const resultado = (await avaliarNoEdge(expression)).valor;
  const shortUrl = resultado?.dados?.urls?.[0]?.short_url;
  if (resultado?.status === 401 || resultado?.status === 403){
    affiliateSession.validatedAt = 0;
    throw criarErro('AFFILIATE_SESSION_REQUIRED', 'sessão afiliada recusada ou expirada');
  }
  if (resultado?.dados?.status !== 200 || !/^https:\/\/meli\.la\/[A-Za-z0-9_-]+$/.test(String(shortUrl || ''))){
    throw criarErro('AFFILIATE_CREATE_FAILED', resultado?.dados?.message || `createLink respondeu HTTP ${resultado?.status || 0}`);
  }
  return shortUrl;
}

function criarErro(code, message){
  const erro = new Error(message);
  erro.code = code;
  return erro;
}

async function trocarCodigo({code, clientSecret}){
  const corpo = new URLSearchParams({
    grant_type:'authorization_code',
    client_id:CLIENT_ID,
    client_secret:clientSecret,
    code,
    redirect_uri:REDIRECT_URI
  });
  const resposta = await fetch('https://api.mercadolibre.com/oauth/token', {
    method:'POST',
    headers:{'Accept':'application/json','Content-Type':'application/x-www-form-urlencoded'},
    body:corpo,
    signal:AbortSignal.timeout(15000)
  });
  const dados = await resposta.json().catch(() => ({}));
  if (!resposta.ok){
    throw criarErro('OAUTH_EXCHANGE_FAILED', dados.message || dados.error || 'Mercado Livre recusou a conexão');
  }
  if (!dados.access_token){
    throw criarErro('OAUTH_INVALID_RESPONSE', 'o Mercado Livre não devolveu um access token');
  }
  oauth.clientSecret = clientSecret;
  oauth.accessToken = dados.access_token;
  // Algumas aplicações retornam apenas access_token conforme os escopos
  // habilitados. Isso é suficiente para a sessão atual; sem refresh_token,
  // o usuário fará nova autorização quando o token expirar.
  oauth.refreshToken = dados.refresh_token || null;
  oauth.expiresAt = Date.now() + Number(dados.expires_in || 0) * 1000;
  oauth.userId = dados.user_id || null;
}

async function mercadoGet(caminho){
  if (!oauth.accessToken) throw criarErro('SESSION_REQUIRED', 'conecte sua conta do Mercado Livre');
  const resposta = await fetch(`https://api.mercadolibre.com${caminho}`, {
    headers:{'Accept':'application/json','Authorization':`Bearer ${oauth.accessToken}`},
    signal:AbortSignal.timeout(15000)
  });
  const dados = await resposta.json().catch(() => ({}));
  if (resposta.status === 401){
    oauth.accessToken = null;
    throw criarErro('SESSION_REQUIRED', 'a sessão do Mercado Livre expirou; conecte novamente');
  }
  if (!resposta.ok){
    throw criarErro(`MERCADOLIVRE_HTTP_${resposta.status}`, dados.message || `Mercado Livre respondeu HTTP ${resposta.status}`);
  }
  return dados;
}

function listaDe(resposta){
  if (Array.isArray(resposta)) return resposta;
  if (Array.isArray(resposta?.content)) return resposta.content;
  if (Array.isArray(resposta?.results)) return resposta.results;
  return [];
}

function escolherOferta(ofertas){
  return [...ofertas]
    .filter(oferta => oferta?.item_id && oferta.price != null && Number.isFinite(Number(oferta.price)) && Number(oferta.price) >= 0)
    .sort((a, b) => Number(a.price) - Number(b.price))[0] || null;
}

function imagemProduto(produto){
  const foto = produto?.pictures?.[0];
  return foto?.secure_url || foto?.url || produto?.thumbnail || null;
}

function mapearAtributosProduto(produto){
  return Object.fromEntries(listaDe(produto?.attributes)
    .filter(atributo => atributo?.id)
    .map(atributo => [String(atributo.id), atributo.value_name ?? atributo.value_id ?? null])
    .filter(([_id, valor]) => valor != null && String(valor).trim()));
}

function primeiroAtributo(atributos, ids){
  for (const id of ids){
    if (atributos[id] != null && String(atributos[id]).trim()) return String(atributos[id]).trim();
  }
  return null;
}

function identidadeCatalogo({catalogProductId, brand, model, partNumber}){
  const chave = [catalogProductId, brand, model, partNumber]
    .map(valor => String(valor || '').trim().toLowerCase())
    .join('|');
  return `ml:${createHash('sha256').update(chave).digest('hex')}`;
}

function nomeCanonicoProduto({titulo, brand, model, partNumber}){
  const componentes = [...new Set([brand, model, partNumber].filter(Boolean).map(String))];
  return componentes.length >= 2 ? componentes.join(' · ') : String(titulo || '').trim();
}

function tituloPublicoProduto({titulo, brand, model, atributos}){
  const detalhes = [
    primeiroAtributo(atributos, ['VIDEO_MEMORY_CAPACITY','RAM_MEMORY','INTERNAL_MEMORY','STORAGE_CAPACITY','CAPACITY']),
    primeiroAtributo(atributos, ['COLOR'])
  ];
  const componentes = [...new Set([brand, model, ...detalhes].filter(Boolean).map(String))];
  const amigavel = componentes.length >= 2 ? componentes.join(' ') : String(titulo || '').trim();
  return amigavel.replace(/\s+/g, ' ').slice(0, 120).trim();
}

async function resolverCategoria(seed){
  if (cacheCategorias.has(seed.id)) return cacheCategorias.get(seed.id);
  const encontrados = await mercadoGet(`/sites/MLB/domain_discovery/search?q=${encodeURIComponent(seed.query)}`);
  const categoriaId = listaDe(encontrados).map(x => x.category_id).find(Boolean);
  if (!categoriaId) throw criarErro('CATEGORY_NOT_FOUND', `categoria não encontrada para ${seed.query}`);
  cacheCategorias.set(seed.id, categoriaId);
  return categoriaId;
}

async function descobrirSemente(limite, categoriaConfig, seed, excluirItemIds = new Set()){
  const categoriaId = await resolverCategoria(seed);
  const highlights = await mercadoGet(`/highlights/MLB/category/${encodeURIComponent(categoriaId)}`);
  const entradas = listaDe(highlights)
    .map((entrada, indice) => ({
      id:entrada.id || entrada.product_id,
      position:entrada.position || indice + 1
    }))
    .filter(entrada => /^MLB\d+$/.test(String(entrada.id || '')))
    .slice(0, 20);

  if (!entradas.length){
    throw criarErro('EMPTY_HIGHLIGHTS', 'o Mercado Livre não retornou produtos populares para a categoria');
  }

  const candidatos = [];
  for (const entrada of entradas){
    try {
      const [produto, respostaOfertas] = await Promise.all([
        mercadoGet(`/products/${encodeURIComponent(entrada.id)}`),
        mercadoGet(`/products/${encodeURIComponent(entrada.id)}/items`)
      ]);
      const oferta = escolherOferta(listaDe(respostaOfertas));
      const titulo = produto.name || produto.title || oferta.title || entrada.id;
      if (!oferta?.item_id || oferta.price == null || !seed.match.test(titulo)) continue;
      if (excluirItemIds.has(String(oferta.item_id))) continue;
      const frete = oferta.shipping?.logistic_type === 'fulfillment'
        ? 'Full'
        : oferta.shipping?.free_shipping ? 'frete grátis' : 'consultar';
      const sourceAttributes = mapearAtributosProduto(produto);
      const brand = primeiroAtributo(sourceAttributes, ['BRAND','MANUFACTURER']);
      const model = primeiroAtributo(sourceAttributes, ['MODEL','DETAILED_MODEL']);
      const partNumber = primeiroAtributo(sourceAttributes, ['PART_NUMBER','MANUFACTURER_PART_NUMBER','MPN']);
      const productIdentity = identidadeCatalogo({catalogProductId:entrada.id, brand, model, partNumber});
      const publicTitle = tituloPublicoProduto({titulo, brand, model, atributos:sourceAttributes});
      candidatos.push({
        catalogProductId:entrada.id,
        itemId:oferta.item_id,
        categoryId:oferta.category_id || produto.category_id || categoriaId,
        editorialCategory:categoriaConfig.id,
        position:entrada.position,
        title:titulo,
        publicTitle,
        sourceTitle:oferta.title || titulo,
        canonicalName:nomeCanonicoProduto({titulo, brand, model, partNumber}),
        productIdentity,
        brand,
        model,
        partNumber,
        sourceAttributes,
        image:imagemProduto(produto),
        price:Number(oferta.price),
        originalPrice:oferta.original_price == null ? null : Number(oferta.original_price),
        sellerId:oferta.seller_id || oferta.seller?.id || null,
        sellerName:oferta.seller?.nickname || null,
        shipping:frete,
        officialStoreId:oferta.official_store_id || null,
        publicUrl:`https://produto.mercadolivre.com.br/${oferta.item_id}`,
        productType:seed.id
      });
      if (candidatos.length >= limite) break;
    } catch (erro) {
      // Um produto inconsistente não deve derrubar toda a fila. Erros de
      // sessão, porém, exigem reconexão imediata.
      if (erro.code === 'SESSION_REQUIRED') throw erro;
    }
  }
  if (!candidatos.length){
    throw criarErro('EMPTY_CANDIDATES', 'nenhuma oferta utilizável foi encontrada nesta busca');
  }
  return candidatos;
}

async function descobrirProdutosReais(limite, categoriaConfig, excluirItemIds = new Set()){
  const quantidadeFamilias = Math.min(10, categoriaConfig.seeds.length, Math.max(1, Math.ceil(limite / 2)));
  const inicio = rotacaoCategorias.get(categoriaConfig.id) || 0;
  const seedsSelecionadas = Array.from({length:quantidadeFamilias}, (_v, indice) =>
    categoriaConfig.seeds[(inicio + indice) % categoriaConfig.seeds.length]
  );
  rotacaoCategorias.set(categoriaConfig.id, (inicio + quantidadeFamilias) % categoriaConfig.seeds.length);
  const porTipo = Math.max(1, Math.min(2, Math.ceil(limite / quantidadeFamilias)));
  const resultados = [];
  for (const seed of seedsSelecionadas){
    try {
      resultados.push(...await descobrirSemente(porTipo, categoriaConfig, seed, excluirItemIds));
    } catch (erro) {
      if (erro.code === 'SESSION_REQUIRED') throw erro;
    }
  }
  return [...new Map(resultados.map(item => [item.itemId, item])).values()].slice(0, limite);
}

async function rotear(req, res){
  const origem = req.headers.origin;
  res.corsOrigin = allowedOrigins.has(origem) ? origem : 'null';
  if (!allowedHosts.has(String(req.headers.host || '').toLowerCase())) {
    return responder(res, 421, {code:'INVALID_HOST', message:'destino local inválido'});
  }
  if (origem && !allowedOrigins.has(origem)) {
    return responder(res, 403, {code:'ORIGIN_NOT_ALLOWED', message:'origem não autorizada'});
  }
  const url = new URL(req.url, `http://${HOST}:${PORT}`);
  if (req.method === 'OPTIONS') return responder(res, 204, {});
  if (req.method === 'POST' && !/^application\/json(?:;|$)/i.test(String(req.headers['content-type'] || ''))) {
    return responder(res, 415, {code:'CONTENT_TYPE_REQUIRED', message:'envie JSON'});
  }

  if (req.method === 'GET' && url.pathname === '/api/health'){
    return responder(res, 200, {ok:true, service:'dropdodia-ml-companion', mode:MODE, version:COMPANION_VERSION});
  }

  if (req.method === 'GET' && url.pathname === '/status'){
    res.writeHead(200, {
      'Content-Type':'text/html; charset=utf-8',
      'Cache-Control':'no-store',
      'X-Content-Type-Options':'nosniff',
      'Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'self'; img-src https://dropdodia.com.br"
    });
    return res.end(`<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Drop do Dia - Curadoria v${COMPANION_VERSION}</title><link rel="icon" href="https://dropdodia.com.br/favicon-32.png">
<style>
*{box-sizing:border-box}body{margin:0;background:#101012;color:#fff;font-family:Segoe UI,Arial,sans-serif}.card{padding:26px;min-height:100vh;border-top:4px solid #ff5b2e}.brand{display:flex;align-items:center;gap:14px}.brand img{width:52px;height:52px;border-radius:13px}.brand h1{font-size:20px;margin:0}.version{color:#aaaab2;margin-top:4px;font-size:14px}.status{display:flex;align-items:center;gap:10px;margin:28px 0 6px;font-size:17px;font-weight:650}.dot{color:#34d36c;font-size:25px;line-height:1}.details{color:#aaaab2;font-size:14px;margin-bottom:25px}.actions{display:grid;grid-template-columns:1fr 1fr;gap:10px}button{border:1px solid #414148;border-radius:9px;padding:12px;background:#1b1b1f;color:#fff;font-weight:650;cursor:pointer}.primary{background:#ff5b2e;border-color:#ff5b2e}.offline .dot{color:#ff4d4f}
</style></head><body><main class="card"><div class="brand"><img src="https://dropdodia.com.br/favicon-192.png" alt=""><div><h1>Drop do Dia - Curadoria</h1><div class="version">Companion v${COMPANION_VERSION}</div></div></div><div class="status"><span class="dot">●</span><span id="state">Serviço ativo</span></div><div class="details" id="details">Conectado localmente na porta 8791</div><div class="actions"><button class="primary" onclick="openAdmin()">Abrir curadoria</button><button onclick="check()">Verificar agora</button></div></main><script>
function openAdmin(){window.open('https://dropdodia.com.br/admin/','_blank')}
async function check(){const box=document.querySelector('.status');try{const r=await fetch('/api/health',{cache:'no-store'}),h=await r.json();if(!h.ok)throw 0;box.classList.remove('offline');state.textContent='Serviço ativo';details.textContent='Conectado na porta 8791 - versão '+h.version}catch(e){box.classList.add('offline');state.textContent='Serviço indisponível';details.textContent='Reinicie o aplicativo e tente novamente.'}}
setInterval(check,5000);check();
</script></body></html>`);
  }

  if (req.method === 'GET' && url.pathname === '/health'){
    return responder(res, 200, {ok:true, mode:oauth.accessToken ? 'real' : MODE, affiliateConfigured:false});
  }

  if (req.method === 'GET' && url.pathname === '/api/oauth/status'){
    return responder(res, 200, {
      connected:!!oauth.accessToken,
      userId:oauth.userId,
      expiresAt:oauth.expiresAt || null
    });
  }

  if (req.method === 'POST' && url.pathname === '/api/oauth/disconnect'){
    oauth.pendingState = null;
    oauth.pendingUntil = 0;
    oauth.clientSecret = null;
    oauth.accessToken = null;
    oauth.refreshToken = null;
    oauth.expiresAt = 0;
    oauth.userId = null;
    cacheCategorias.clear();
    return responder(res, 200, {connected:false});
  }

  if (req.method === 'GET' && url.pathname === '/api/categories'){
    return responder(res, 200, {categories:CATEGORIAS.map(({id, name}) => ({id, name}))});
  }

  if (req.method === 'GET' && url.pathname === '/api/affiliate/status'){
    try {
      const status = await detectarSessaoAfiliada();
      return responder(res, 200, {...status, validatedAt:affiliateSession.validatedAt || null});
    } catch {
      return responder(res, 200, {configured:false, browserOpen:false});
    }
  }

  if (req.method === 'POST' && url.pathname === '/api/affiliate/browser/start'){
    const perfil = path.join(__dirname, '.affiliate-profile');
    const argumentos = [
      `--remote-debugging-port=${EDGE_DEBUG_PORT}`,
      '--remote-debugging-address=127.0.0.1',
      `--user-data-dir=${perfil}`,
      '--no-first-run', '--no-default-browser-check', '--new-window',
      'https://www.mercadolivre.com.br/'
    ];
    const processo = spawn(EDGE_PATH, argumentos, {detached:true, stdio:'ignore'});
    processo.unref();
    affiliateSession.browserProcess = processo.pid;
    affiliateSession.validatedAt = 0;
    // Quando o perfil dedicado já está aberto, o Edge pode restaurar a aba
    // anterior e ignorar a URL recebida. A porta de depuração cria uma aba
    // nova explicitamente e remove apenas a antiga rota quebrada.
    const destino = 'https://www.mercadolivre.com.br/';
    let novaAba = null;
    for (let tentativa = 0; tentativa < 12 && !novaAba; tentativa += 1){
      await new Promise(resolve => setTimeout(resolve, 500));
      try {
        const novaResposta = await fetch(
          `http://127.0.0.1:${EDGE_DEBUG_PORT}/json/new?${encodeURIComponent(destino)}`,
          {method:'PUT', signal:AbortSignal.timeout(2000)}
        );
        if (novaResposta.ok) novaAba = await novaResposta.json();
      } catch {}
    }
    // O Edge já abre `destino` pelos argumentos do processo. Em algumas
    // versões, /json/new abre a página mas não devolve o alvo (ou responde
    // antes de ele ficar disponível). Confirma pela lista da mesma sessão de
    // depuração para não informar uma falha quando a aba está visível.
    let abas = [];
    for (let tentativa = 0; tentativa < 8; tentativa += 1){
      try {
        const listaResposta = await fetch(`http://127.0.0.1:${EDGE_DEBUG_PORT}/json/list`, {signal:AbortSignal.timeout(3000)});
        if (listaResposta.ok) abas = await listaResposta.json();
      } catch {}
      const abaCriada = novaAba?.id && abas.find(alvo => alvo.id === novaAba.id);
      const abaMercadoLivre = abas.find(alvo =>
        alvo.type === 'page' && /https?:\/\/([^.]+\.)?mercadolivre\.com\.br(?:\/|$)/i.test(alvo.url || '')
      );
      novaAba = abaCriada || abaMercadoLivre || novaAba;
      if (novaAba?.id) break;
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    if (!novaAba?.id){
      throw criarErro('AFFILIATE_BROWSER_REQUIRED', 'o Edge abriu, mas o companion não conseguiu acessar a aba do Mercado Livre; feche a janela e tente novamente');
    }
    // Mantém uma única aba no perfil dedicado. Várias abas do Mercado Livre
    // faziam a validação escolher uma página sem o Gerador de Links.
    const antigas = abas.filter(alvo => alvo.type === 'page' && alvo.id !== novaAba.id);
    await Promise.all(antigas.map(alvo =>
      fetch(`http://127.0.0.1:${EDGE_DEBUG_PORT}/json/close/${encodeURIComponent(alvo.id)}`, {signal:AbortSignal.timeout(3000)}).catch(() => null)
    ));
    await fetch(`http://127.0.0.1:${EDGE_DEBUG_PORT}/json/activate/${encodeURIComponent(novaAba.id)}`, {signal:AbortSignal.timeout(3000)});
    return responder(res, 200, {started:true, destination:destino});
  }

  if (req.method === 'POST' && url.pathname === '/api/oauth/start'){
    oauth.pendingState = randomUUID();
    oauth.pendingUntil = Date.now() + 10 * 60 * 1000;
    const autorizacao = new URL('https://auth.mercadolivre.com.br/authorization');
    autorizacao.searchParams.set('response_type', 'code');
    autorizacao.searchParams.set('client_id', CLIENT_ID);
    autorizacao.searchParams.set('redirect_uri', REDIRECT_URI);
    autorizacao.searchParams.set('state', oauth.pendingState);
    return responder(res, 200, {authorizationUrl:autorizacao.toString()});
  }

  if (req.method === 'POST' && url.pathname === '/api/oauth/complete'){
    const corpo = await lerJson(req);
    if (!oauth.pendingState || Date.now() > oauth.pendingUntil){
      throw criarErro('OAUTH_STATE_EXPIRED', 'a autorização expirou; clique em abrir autorização novamente');
    }
    let retorno;
    try { retorno = new URL(corpo.redirectUrl); }
    catch { throw criarErro('INVALID_REDIRECT_URL', 'cole a URL completa recebida do Mercado Livre'); }
    const origensPermitidas = new Set([
      'https://dropdodia.com.br',
      'https://www.dropdodia.com.br'
    ]);
    if (!origensPermitidas.has(retorno.origin)){
      throw criarErro('INVALID_REDIRECT_URL', 'a URL precisa ser do domínio dropdodia.com.br');
    }
    if (retorno.searchParams.get('state') !== oauth.pendingState){
      throw criarErro('OAUTH_STATE_MISMATCH', 'o código não pertence à autorização iniciada neste painel');
    }
    const code = retorno.searchParams.get('code');
    if (!code) throw criarErro('OAUTH_CODE_MISSING', 'a URL não contém o código de autorização');
    if (!corpo.clientSecret) throw criarErro('CLIENT_SECRET_MISSING', 'Client Secret não informado');
    await trocarCodigo({code, clientSecret:corpo.clientSecret});
    oauth.pendingState = null;
    oauth.pendingUntil = 0;
    return responder(res, 200, {
      connected:true,
      userId:oauth.userId,
      expiresAt:oauth.expiresAt,
      renewable:!!oauth.refreshToken
    });
  }

  if (req.method === 'GET' && url.pathname === '/api/discovery'){
    const limite = Math.min(20, Math.max(1, Number(url.searchParams.get('limit')) || 20));
    const categoriaConfig = CATEGORIAS.find(c => c.id === url.searchParams.get('category')) || CATEGORIAS[0];
    if (!oauth.accessToken) throw criarErro('SESSION_REQUIRED', 'conecte sua conta do Mercado Livre antes de buscar produtos');
    const anteriores = ultimaDescobertaPorCategoria.get(categoriaConfig.id) || new Set();
    const candidates = await descobrirProdutosReais(limite, categoriaConfig, anteriores);
    ultimaDescobertaPorCategoria.set(categoriaConfig.id, new Set(candidates.map(item => String(item.itemId))));
    return responder(res, 200, {candidates, source:'mercadolivre'});
  }

  if (req.method === 'GET' && url.pathname === '/api/discovery/all'){
    const limite = Math.min(20, Math.max(1, Number(url.searchParams.get('limit')) || 20));
    if (!oauth.accessToken) throw criarErro('SESSION_REQUIRED', 'conecte sua conta do Mercado Livre');
    const resultados = await Promise.all(CATEGORIAS.map(async categoria => {
      const anteriores = ultimaDescobertaPorCategoria.get(categoria.id) || new Set();
      const candidatos = await descobrirProdutosReais(limite, categoria, anteriores);
      ultimaDescobertaPorCategoria.set(categoria.id, new Set(candidatos.map(item => String(item.itemId))));
      return [categoria.id, candidatos];
    }));
    const categories = Object.fromEntries(resultados);
    return responder(res, 200, {categories, source:'mercadolivre'});
  }

  if (req.method === 'POST' && url.pathname === '/api/approve'){
    const corpo = await lerJson(req);
    if (oauth.accessToken){
      const candidato = corpo.candidate;
      const respostaOfertas = await mercadoGet(`/products/${encodeURIComponent(candidato.catalogProductId)}/items`);
      const oferta = escolherOferta(listaDe(respostaOfertas));
      if (!oferta || oferta.price == null){
        throw criarErro('OFFER_UNAVAILABLE', 'a oferta não está mais disponível');
      }
      const publicUrl = urlPublicaItem(oferta.item_id);
      const affiliateUrl = await criarLinkAfiliado(publicUrl);
      const atualizado = {
        ...candidato,
        itemId:String(oferta.item_id),
        price:Number(oferta.price),
        originalPrice:oferta.original_price == null ? null : Number(oferta.original_price),
        publicUrl,
        affiliateUrl
      };
      return responder(res, 200, {
        workflowId:randomUUID(),
        preview:true,
        affiliateUrl,
        product:produtoDePrevia(atualizado)
      });
    }
    const workflowId = randomUUID();
    return responder(res, 200, {
      workflowId,
      preview:true,
      product:produtoDePrevia(corpo.candidate)
    });
  }

  if (req.method === 'POST' && url.pathname === '/api/affiliate/link'){
    const corpo = await lerJson(req);
    const publicUrl = urlPublicaItem(corpo.itemId);
    const affiliateUrl = await criarLinkAfiliado(publicUrl);
    return responder(res, 200, {affiliateUrl, itemId:String(corpo.itemId)});
  }

  if (req.method === 'POST' && url.pathname === '/api/prices/check'){
    if (!oauth.accessToken) throw criarErro('SESSION_REQUIRED', 'conecte sua conta do Mercado Livre antes de verificar preços');
    const corpo = await lerJson(req);
    const results = await verificarPrecosMercadoLivre(corpo.items);
    return responder(res, 200, {results, checkedAt:new Date().toISOString()});
  }

  responder(res, 404, {code:'NOT_FOUND', message:'rota inexistente'});
}

const servidor = http.createServer((req, res) => {
  rotear(req, res).catch(erro => responder(res, 400, {
    code:erro.code || 'BAD_REQUEST',
    message:erro.message || 'requisição inválida'
  }));
});

if (require.main === module){
  servidor.listen(PORT, HOST, () => {
    console.log(`ML companion (${MODE}) em http://${HOST}:${PORT}`);
  });
}

module.exports = {
  escolherOferta,
  identidadeCatalogo,
  nomeCanonicoProduto,
  tituloPublicoProduto,
  produtoDePrevia
};
