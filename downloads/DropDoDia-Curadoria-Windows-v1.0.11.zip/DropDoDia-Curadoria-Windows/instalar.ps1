$ErrorActionPreference = 'Stop'

$packageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$appRoot = Join-Path $env:LOCALAPPDATA 'Programs\Drop do Dia - Companion'
$companionRoot = Join-Path $appRoot 'resources\companion'
$executable = Join-Path $appRoot 'Drop do Dia - Companion.exe'
$logRoot = Join-Path $env:LOCALAPPDATA 'DropDoDia\logs'
$logPath = Join-Path $logRoot 'instalacao.log'

function Write-InstallLog([string]$message) {
  New-Item -ItemType Directory -Force -Path $logRoot | Out-Null
  Add-Content -LiteralPath $logPath -Value "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff')] $message" -Encoding UTF8
}

try {
  Write-InstallLog 'Iniciando atualização incremental do companion.'
  Start-Sleep -Seconds 3
  Get-Process -Name 'Drop do Dia - Companion' -ErrorAction SilentlyContinue |
    Stop-Process -Force -ErrorAction SilentlyContinue
  Start-Sleep -Seconds 2

  if (-not (Test-Path -LiteralPath $executable -PathType Leaf)) {
    throw 'A instalação Electron existente não foi encontrada.'
  }

  New-Item -ItemType Directory -Force -Path (Join-Path $companionRoot 'app') | Out-Null
  Copy-Item -LiteralPath (Join-Path $packageRoot 'server.js') -Destination (Join-Path $companionRoot 'app\server.js') -Force
  Copy-Item -LiteralPath (Join-Path $packageRoot 'atualizar.ps1') -Destination (Join-Path $companionRoot 'atualizar.ps1') -Force
  Copy-Item -LiteralPath (Join-Path $packageRoot 'version.json') -Destination (Join-Path $companionRoot 'version.json') -Force

  Write-InstallLog 'Atualização incremental instalada; reabrindo o aplicativo.'
  Start-Process -FilePath $executable -WorkingDirectory $appRoot
} catch {
  Write-InstallLog "Falha na atualização incremental: $($_.Exception.Message)"
}
